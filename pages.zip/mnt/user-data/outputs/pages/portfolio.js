import { useEffect, useState } from 'react'
import { useRouter } from 'next/router'
import Head from 'next/head'
import Link from 'next/link'
import { useAuth } from '../lib/auth'
import { supabase } from '../lib/supabase'
import Navbar from '../components/Navbar'
import { formatRupees } from '../lib/markets'

const INITIAL_BALANCE = 1000000

export default function PortfolioPage() {
  const { user, loading } = useAuth()
  const router = useRouter()
  const [trades, setTrades] = useState([])
  const [leaderboard, setLeaderboard] = useState([])
  const [fetching, setFetching] = useState(true)

  useEffect(() => {
    if (!loading && !user) router.replace('/login')
  }, [user, loading])

  useEffect(() => {
    if (!user) return
    fetchTrades()
    fetchLeaderboard()
  }, [user])

  const fetchTrades = async () => {
    setFetching(true)
    const { data } = await supabase
      .from('trades')
      .select('*, markets(id, question, yes_price, no_price)')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
    if (data) setTrades(data)
    setFetching(false)
  }

  const fetchLeaderboard = async () => {
    const { data } = await supabase
      .from('users')
      .select('id, username, balance')
      .order('balance', { ascending: false })
      .limit(10)
    if (data) setLeaderboard(data)
  }

  const totalSpent = trades.reduce((s, t) => s + (t.amount || 0), 0)
  const yesCount = trades.filter((t) => t.side === 'YES').length
  const noCount = trades.filter((t) => t.side === 'NO').length
  const pnl = user ? user.balance - INITIAL_BALANCE : 0
  const yesRatio = trades.length ? (yesCount / trades.length) * 100 : 50

  if (loading || !user) return null

  const medals = ['🥇', '🥈', '🥉']

  return (
    <>
      <Head><title>Portfolio — PredMarket</title></Head>

      <style>{`
        @keyframes fadeSlideUp { from { opacity:0;transform:translateY(12px) } to { opacity:1;transform:translateY(0) } }
        .portfolio-card { animation: fadeSlideUp 0.4s ease-out both; }
        .trade-row:hover { background: rgba(255,255,255,0.02); }
      `}</style>

      <div style={{ minHeight: '100vh', background: '#0D0F14', fontFamily: "'Syne', sans-serif" }}>
        <Navbar />

        <div style={{ maxWidth: 1100, margin: '0 auto', padding: '32px 20px' }}>

          {/* Header */}
          <div style={{ marginBottom: 28 }}>
            <h1 style={{ color: 'white', fontSize: 32, fontWeight: 900, margin: 0, letterSpacing: '-0.02em' }}>
              My Portfolio
            </h1>
            <p style={{ color: '#6B7280', marginTop: 6, fontFamily: 'monospace', fontSize: 13 }}>
              {user.username}
            </p>
          </div>

          {/* Stats */}
          <div className="portfolio-card" style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 14, marginBottom: 20 }}>
            {[
              { label: 'Balance', value: formatRupees(user.balance), color: 'white' },
              {
                label: 'P&L vs Start',
                value: `${pnl >= 0 ? '+' : ''}${formatRupees(pnl)}`,
                color: pnl >= 0 ? '#00C278' : '#FF4D4D',
              },
              { label: 'Total Trades', value: trades.length, color: 'white' },
              { label: 'Total Spent', value: formatRupees(totalSpent), color: '#9CA3AF' },
            ].map(({ label, value, color }) => (
              <div key={label} style={{ background: '#141720', border: '1px solid #1E2330', borderRadius: 14, padding: '16px 20px' }}>
                <div style={{ color: '#6B7280', fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 4 }}>{label}</div>
                <div style={{ color, fontSize: 20, fontWeight: 900, fontFamily: 'monospace' }}>{value}</div>
              </div>
            ))}
          </div>

          {/* YES / NO ratio bar */}
          {trades.length > 0 && (
            <div style={{ background: '#141720', border: '1px solid #1E2330', borderRadius: 14, padding: '14px 20px', marginBottom: 24 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8, fontSize: 12, fontFamily: 'monospace', color: '#6B7280' }}>
                <span style={{ color: '#00C278' }}>YES: {yesCount} trades ({yesRatio.toFixed(0)}%)</span>
                <span style={{ color: '#FF4D4D' }}>NO: {noCount} trades ({(100 - yesRatio).toFixed(0)}%)</span>
              </div>
              <div style={{ display: 'flex', height: 6, borderRadius: 99, overflow: 'hidden', gap: 2 }}>
                <div style={{ background: '#00C278', width: `${yesRatio}%`, borderRadius: 99, transition: 'width 0.6s ease' }} />
                <div style={{ background: '#FF4D4D', flex: 1, borderRadius: 99 }} />
              </div>
            </div>
          )}

          {/* Two columns: trades + leaderboard */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: 20, alignItems: 'start' }}>

            {/* Trade history */}
            <div style={{ background: '#141720', border: '1px solid #1E2330', borderRadius: 18, padding: 24 }}>
              <h2 style={{ color: 'white', fontSize: 16, fontWeight: 700, margin: '0 0 20px' }}>
                Trade History
              </h2>

              {fetching ? (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  {Array.from({ length: 5 }).map((_, i) => (
                    <div key={i} style={{ height: 56, background: '#0D0F14', borderRadius: 10, opacity: 0.6 }} />
                  ))}
                </div>
              ) : trades.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '48px 0' }}>
                  <div style={{ fontSize: 44, marginBottom: 12 }}>📊</div>
                  <div style={{ color: '#6B7280', fontSize: 14, marginBottom: 12 }}>No trades yet</div>
                  <Link href="/markets" style={{ color: '#1652F0', fontSize: 13, textDecoration: 'none', fontWeight: 600 }}>
                    Browse Markets →
                  </Link>
                </div>
              ) : (
                <div>
                  {trades.map((trade, idx) => {
                    const name = trade.markets?.question?.replace(' will cry on farewell speech?', '') || '—'
                    const isYes = trade.side === 'YES'
                    return (
                      <Link
                        href={`/market/${trade.markets?.id || '#'}`}
                        key={trade.id}
                        style={{ textDecoration: 'none', display: 'block' }}
                      >
                        <div
                          className="trade-row"
                          style={{
                            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                            padding: '12px 10px', borderRadius: 10, cursor: 'pointer',
                            borderBottom: idx < trades.length - 1 ? '1px solid #1E2330' : 'none',
                            transition: 'background 0.15s',
                          }}
                        >
                          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                            <div style={{
                              width: 34, height: 34, borderRadius: 9, display: 'flex',
                              alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700,
                              background: isYes ? 'rgba(0,194,120,0.12)' : 'rgba(255,77,77,0.12)',
                              color: isYes ? '#00C278' : '#FF4D4D',
                              border: `1px solid ${isYes ? 'rgba(0,194,120,0.25)' : 'rgba(255,77,77,0.25)'}`,
                            }}>
                              {trade.side[0]}
                            </div>
                            <div>
                              <div style={{ color: 'white', fontSize: 13, fontWeight: 600 }}>{name}</div>
                              <div style={{ color: '#6B7280', fontSize: 11, fontFamily: 'monospace', marginTop: 2 }}>
                                {new Date(trade.created_at).toLocaleString('en-IN', {
                                  day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit'
                                })}
                              </div>
                            </div>
                          </div>
                          <div style={{ textAlign: 'right' }}>
                            <div style={{
                              color: isYes ? '#00C278' : '#FF4D4D',
                              fontFamily: 'monospace', fontSize: 13, fontWeight: 700,
                            }}>
                              Buy {trade.side}
                            </div>
                            <div style={{ color: '#9CA3AF', fontFamily: 'monospace', fontSize: 11, marginTop: 2 }}>
                              -{formatRupees(trade.amount)}
                            </div>
                          </div>
                        </div>
                      </Link>
                    )
                  })}
                </div>
              )}
            </div>

            {/* Leaderboard */}
            <div style={{ background: '#141720', border: '1px solid #1E2330', borderRadius: 18, padding: 24 }}>
              <h2 style={{ color: 'white', fontSize: 16, fontWeight: 700, margin: '0 0 20px' }}>
                🏆 Leaderboard
              </h2>
              <div>
                {leaderboard.map((u, i) => {
                  const isMe = u.id === user.id
                  return (
                    <div key={u.id} style={{
                      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                      padding: '10px 12px', borderRadius: 10, marginBottom: 6,
                      background: isMe ? 'rgba(22,82,240,0.08)' : 'transparent',
                      border: isMe ? '1px solid rgba(22,82,240,0.2)' : '1px solid transparent',
                      transition: 'background 0.15s',
                    }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                        <span style={{ fontSize: 14, width: 20, textAlign: 'center' }}>
                          {medals[i] || <span style={{ color: '#6B7280', fontFamily: 'monospace', fontSize: 12 }}>{i + 1}</span>}
                        </span>
                        <div style={{
                          width: 26, height: 26, borderRadius: '50%', background: '#1E2330',
                          display: 'flex', alignItems: 'center', justifyContent: 'center',
                          fontSize: 11, fontWeight: 700, color: isMe ? '#1652F0' : '#9CA3AF',
                        }}>
                          {u.username[0].toUpperCase()}
                        </div>
                        <span style={{ fontSize: 13, fontWeight: 600, color: isMe ? '#93B4FF' : 'white' }}>
                          {u.username}
                        </span>
                      </div>
                      <span style={{ fontFamily: 'monospace', fontSize: 12, color: '#00C278', fontWeight: 700 }}>
                        {formatRupees(u.balance)}
                      </span>
                    </div>
                  )
                })}
              </div>
            </div>

          </div>
        </div>
      </div>
    </>
  )
}
