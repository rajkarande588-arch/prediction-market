import { useEffect, useState, useRef } from 'react'
import { useRouter } from 'next/router'
import Head from 'next/head'
import Link from 'next/link'
import { useAuth } from '../lib/auth'
import { supabase } from '../lib/supabase'
import Navbar from '../components/Navbar'
import MarketCard from '../components/MarketCard'
import { formatRupees } from '../lib/markets'

export default function MarketsPage() {
  const { user, loading } = useAuth()
  const router = useRouter()
  const [markets, setMarkets] = useState([])
  const [fetching, setFetching] = useState(true)
  const [search, setSearch] = useState('')
  const [sortBy, setSortBy] = useState('name')
  const channelRef = useRef(null)

  useEffect(() => {
    if (!loading && !user) router.replace('/login')
  }, [user, loading])

  useEffect(() => {
    if (!user) return
    fetchMarkets()

    // Realtime subscription
    channelRef.current = supabase
      .channel('all-markets-realtime')
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'markets',
      }, (payload) => {
        setMarkets((prev) =>
          prev.map((m) => (m.id === payload.new.id ? { ...m, ...payload.new } : m))
        )
      })
      .subscribe()

    return () => {
      if (channelRef.current) supabase.removeChannel(channelRef.current)
    }
  }, [user])

  const fetchMarkets = async () => {
    setFetching(true)
    const { data, error } = await supabase
      .from('markets')
      .select('*')
      .order('question', { ascending: true })
    if (!error && data) setMarkets(data)
    setFetching(false)
  }

  const filtered = markets
    .filter((m) => m.question.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => {
      if (sortBy === 'volume') return (b.volume || 0) - (a.volume || 0)
      if (sortBy === 'yes_high') return b.yes_price - a.yes_price
      if (sortBy === 'yes_low') return a.yes_price - b.yes_price
      return a.question.localeCompare(b.question)
    })

  const totalVolume = markets.reduce((s, m) => s + (m.volume || 0), 0)

  if (loading || !user) return null

  return (
    <>
      <Head><title>Markets — PredMarket</title></Head>

      <style>{`
        @keyframes livePulse { 0%,100% { opacity:1;transform:scale(1) } 50% { opacity:0.4;transform:scale(1.6) } }
        .live-dot { animation: livePulse 2s ease-in-out infinite; }
        @keyframes shimmer { 0% { background-position: -400px 0 } 100% { background-position: 400px 0 } }
        .skeleton {
          background: linear-gradient(90deg, #141720 25%, #1E2330 50%, #141720 75%);
          background-size: 400px 100%;
          animation: shimmer 1.4s ease infinite;
          border-radius: 12px;
        }
        .search-input {
          background: #141720; border: 1px solid #1E2330; border-radius: 10px;
          padding: 10px 16px; color: white; font-size: 14px; font-family: 'Syne', sans-serif;
          outline: none; transition: border-color 0.2s; flex: 1;
        }
        .search-input:focus { border-color: #1652F0; }
        .search-input::placeholder { color: #4B5563; }
        .sort-select {
          background: #141720; border: 1px solid #1E2330; border-radius: 10px;
          padding: 10px 16px; color: white; font-size: 14px; font-family: 'Syne', sans-serif;
          outline: none; cursor: pointer; min-width: 160px;
        }
      `}</style>

      <div style={{ minHeight: '100vh', background: '#0D0F14', fontFamily: "'Syne', sans-serif" }}>
        <Navbar />

        <div style={{ maxWidth: 1280, margin: '0 auto', padding: '32px 20px' }}>

          {/* Page header */}
          <div style={{ marginBottom: 32 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
              <div className="live-dot" style={{ width: 8, height: 8, borderRadius: '50%', background: '#00C278' }} />
              <span style={{ color: '#00C278', fontSize: 11, fontFamily: 'monospace', letterSpacing: '0.12em', textTransform: 'uppercase' }}>
                Live Markets
              </span>
            </div>
            <h1 style={{ color: 'white', fontSize: 32, fontWeight: 900, margin: 0, letterSpacing: '-0.02em' }}>
              MFT Farewell Markets
            </h1>
            <p style={{ color: '#6B7280', marginTop: 6, fontSize: 14 }}>
              Who will cry at the farewell? Trade your prediction.
            </p>
          </div>

          {/* Stats bar */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 28 }}>
            {[
              { label: 'Active Markets', value: markets.length, color: 'white', mono: false },
              { label: 'Total Volume', value: formatRupees(totalVolume), color: 'white', mono: true },
              { label: 'Your Balance', value: formatRupees(user.balance), color: '#00C278', mono: true },
            ].map(({ label, value, color, mono }) => (
              <div key={label} style={{ background: '#141720', border: '1px solid #1E2330', borderRadius: 14, padding: '16px 20px' }}>
                <div style={{ color: '#6B7280', fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 4 }}>{label}</div>
                <div style={{ color, fontSize: 22, fontWeight: 900, fontFamily: mono ? 'monospace' : 'inherit' }}>{value}</div>
              </div>
            ))}
          </div>

          {/* Search + sort */}
          <div style={{ display: 'flex', gap: 12, marginBottom: 24, flexWrap: 'wrap' }}>
            <input
              type="text"
              placeholder="Search markets..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="search-input"
            />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="sort-select"
            >
              <option value="name">Sort: Name</option>
              <option value="volume">Sort: Volume ↓</option>
              <option value="yes_high">Sort: YES High</option>
              <option value="yes_low">Sort: YES Low</option>
            </select>
          </div>

          {/* Markets grid */}
          {fetching ? (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 16 }}>
              {Array.from({ length: 12 }).map((_, i) => (
                <div key={i} className="skeleton" style={{ height: 148 }} />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '64px 0', color: '#6B7280' }}>
              <div style={{ fontSize: 40, marginBottom: 12 }}>🔍</div>
              <div>No markets match your search.</div>
            </div>
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 16 }}>
              {filtered.map((market) => (
                <MarketCard key={market.id} market={market} />
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  )
}
