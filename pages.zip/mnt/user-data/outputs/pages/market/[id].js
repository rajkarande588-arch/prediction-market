import { useEffect, useState, useRef } from 'react'
import { useRouter } from 'next/router'
import Head from 'next/head'
import Link from 'next/link'
import { useAuth } from '../../lib/auth'
import { supabase } from '../../lib/supabase'
import { formatRupees, calculateNewPrices } from '../../lib/markets'
import Navbar from '../../components/Navbar'

const QUICK_AMOUNTS = [1000, 5000, 10000, 50000, 100000]

// ─── Trade Panel (inline, no modal) ─────────────────────────────────────────
function TradePanel({ market, onTrade }) {
  const { user, refreshUser } = useAuth()
  const [side, setSide] = useState('YES')
  const [amount, setAmount] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)

  const num = parseFloat(amount) || 0
  const price = side === 'YES' ? market.yes_price : market.no_price
  const shares = num > 0 ? (num / price).toFixed(2) : '0.00'
  const { yes_price: newYes, no_price: newNo } = num > 0
    ? calculateNewPrices(market.yes_price, num, side)
    : { yes_price: market.yes_price, no_price: market.no_price }

  const handleTrade = async () => {
    setError('')
    if (!num || num <= 0) { setError('Enter an amount'); return }
    if (num < 100) { setError('Minimum trade is ₹100'); return }
    if (num > user.balance) { setError('Insufficient balance'); return }

    setLoading(true)
    try {
      const { error: tradeErr } = await supabase.from('trades').insert({
        user_id: user.id,
        market_id: market.id,
        side,
        amount: num,
      })
      if (tradeErr) throw tradeErr

      const { error: marketErr } = await supabase
        .from('markets')
        .update({ yes_price: newYes, no_price: newNo, volume: (market.volume || 0) + num })
        .eq('id', market.id)
      if (marketErr) throw marketErr

      const { error: userErr } = await supabase
        .from('users')
        .update({ balance: user.balance - num })
        .eq('id', user.id)
      if (userErr) throw userErr

      await refreshUser()
      setSuccess(true)
      setAmount('')
      setTimeout(() => {
        setSuccess(false)
        onTrade && onTrade()
      }, 1500)
    } catch (err) {
      setError(err.message || 'Trade failed. Try again.')
    } finally {
      setLoading(false)
    }
  }

  const isYes = side === 'YES'

  return (
    <div style={{ background: '#141720', border: '1px solid #1E2330', borderRadius: 18, padding: 24 }}>
      <h3 style={{ color: 'white', fontSize: 15, fontWeight: 700, margin: '0 0 16px' }}>Place Trade</h3>

      {/* YES / NO toggle */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 20, background: '#0D0F14', borderRadius: 12, padding: 4 }}>
        {['YES', 'NO'].map((s) => (
          <button
            key={s}
            onClick={() => setSide(s)}
            style={{
              flex: 1, padding: '10px 0', borderRadius: 9, border: 'none', cursor: 'pointer',
              fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 14,
              transition: 'all 0.2s',
              background: side === s
                ? s === 'YES' ? '#00C278' : '#FF4D4D'
                : 'transparent',
              color: side === s ? (s === 'YES' ? '#000' : '#fff') : '#6B7280',
            }}
          >
            {s} — {s === 'YES' ? (market.yes_price / 10).toFixed(1) : (market.no_price / 10).toFixed(1)}%
          </button>
        ))}
      </div>

      {/* Current price */}
      <div style={{
        background: '#0D0F14', borderRadius: 10, padding: '10px 14px',
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        marginBottom: 14, fontSize: 13,
      }}>
        <span style={{ color: '#6B7280' }}>Price per share</span>
        <span style={{ color: isYes ? '#00C278' : '#FF4D4D', fontFamily: 'monospace', fontWeight: 700, fontSize: 16 }}>
          ₹{price}
        </span>
      </div>

      {/* Amount input */}
      <div style={{ marginBottom: 10 }}>
        <label style={{ display: 'block', color: '#9CA3AF', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 6 }}>
          Amount (₹)
        </label>
        <div style={{ position: 'relative' }}>
          <span style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: '#6B7280', fontFamily: 'monospace' }}>₹</span>
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="0"
            style={{
              width: '100%', boxSizing: 'border-box', background: '#0D0F14',
              border: '1px solid #1E2330', borderRadius: 10, padding: '12px 14px 12px 30px',
              color: 'white', fontSize: 16, fontFamily: 'monospace', outline: 'none',
              transition: 'border-color 0.2s',
            }}
            onFocus={e => e.target.style.borderColor = '#1652F0'}
            onBlur={e => e.target.style.borderColor = '#1E2330'}
          />
        </div>
      </div>

      {/* Quick amounts */}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 16 }}>
        {QUICK_AMOUNTS.map((q) => (
          <button
            key={q}
            onClick={() => setAmount(String(q))}
            style={{
              background: '#0D0F14', border: '1px solid #1E2330', borderRadius: 7,
              padding: '6px 10px', color: '#9CA3AF', fontSize: 11, fontFamily: 'monospace',
              cursor: 'pointer', transition: 'all 0.15s',
            }}
            onMouseOver={e => { e.target.style.borderColor = '#2A3347'; e.target.style.color = 'white' }}
            onMouseOut={e => { e.target.style.borderColor = '#1E2330'; e.target.style.color = '#9CA3AF' }}
          >
            {formatRupees(q)}
          </button>
        ))}
        <button
          onClick={() => setAmount(String(Math.floor(user?.balance || 0)))}
          style={{
            background: '#0D0F14', border: '1px solid rgba(234,179,8,0.3)', borderRadius: 7,
            padding: '6px 10px', color: '#EAB308', fontSize: 11, fontFamily: 'monospace',
            cursor: 'pointer', fontWeight: 700,
          }}
        >
          MAX
        </button>
      </div>

      {/* Summary */}
      {num > 0 && (
        <div style={{
          background: '#0D0F14', borderRadius: 10, padding: '12px 14px',
          marginBottom: 14, fontSize: 12, fontFamily: 'monospace',
        }}>
          {[
            ['Shares', `${shares} shares`],
            ['New YES price', `₹${newYes} (${(newYes / 10).toFixed(1)}%)`, newYes > market.yes_price ? '#00C278' : '#FF4D4D'],
            ['Balance after', formatRupees(user.balance - num)],
          ].map(([k, v, c]) => (
            <div key={k} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6, ':last-child': { marginBottom: 0 } }}>
              <span style={{ color: '#6B7280' }}>{k}</span>
              <span style={{ color: c || 'white' }}>{v}</span>
            </div>
          ))}
        </div>
      )}

      {/* Error */}
      {error && (
        <div style={{
          background: 'rgba(255,77,77,0.1)', border: '1px solid rgba(255,77,77,0.25)',
          borderRadius: 9, padding: '10px 14px', marginBottom: 12, color: '#FF6B6B', fontSize: 13,
        }}>
          {error}
        </div>
      )}

      {/* Success */}
      {success && (
        <div style={{
          background: 'rgba(0,194,120,0.1)', border: '1px solid rgba(0,194,120,0.25)',
          borderRadius: 9, padding: '10px 14px', marginBottom: 12,
          color: '#00C278', fontSize: 13, textAlign: 'center', fontWeight: 600,
        }}>
          ✓ Trade executed successfully!
        </div>
      )}

      {/* CTA */}
      <button
        onClick={handleTrade}
        disabled={loading || success}
        style={{
          width: '100%', padding: '14px 0', borderRadius: 12, border: 'none', cursor: 'pointer',
          fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 15,
          background: isYes ? '#00C278' : '#FF4D4D',
          color: isYes ? '#000' : '#fff',
          opacity: (loading || success) ? 0.6 : 1,
          transition: 'all 0.2s',
        }}
      >
        {loading ? 'Processing...' : success ? '✓ Done!' : `Buy ${side} · ${formatRupees(num || 0)}`}
      </button>

      <p style={{ textAlign: 'center', color: '#4B5563', fontSize: 12, marginTop: 10, fontFamily: 'monospace' }}>
        Balance: {formatRupees(user?.balance || 0)}
      </p>
    </div>
  )
}

// ─── Main Page ───────────────────────────────────────────────────────────────
export default function MarketPage() {
  const { user, loading } = useAuth()
  const router = useRouter()
  const { id } = router.query

  const [market, setMarket] = useState(null)
  const [trades, setTrades] = useState([])
  const [fetching, setFetching] = useState(true)
  const [priceHistory, setPriceHistory] = useState([])
  const prevYesRef = useRef(null)
  const priceCardRef = useRef(null)
  const channelRef = useRef(null)

  useEffect(() => {
    if (!loading && !user) router.replace('/login')
  }, [user, loading])

  useEffect(() => {
    if (!id || !user) return
    fetchMarket()
    fetchTrades()

    channelRef.current = supabase
      .channel(`market-page-${id}`)
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'markets',
        filter: `id=eq.${id}`,
      }, (payload) => {
        const prev = prevYesRef.current
        const next = payload.new.yes_price
        setMarket(payload.new)

        setPriceHistory((ph) => [
          ...ph.slice(-29),
          { time: new Date().toLocaleTimeString(), yes: payload.new.yes_price, no: payload.new.no_price },
        ])

        // Flash card
        if (priceCardRef.current) {
          const color = next > prev ? 'rgba(0,194,120,0.12)' : 'rgba(255,77,77,0.12)'
          priceCardRef.current.style.background = color
          setTimeout(() => {
            if (priceCardRef.current) priceCardRef.current.style.background = ''
          }, 700)
        }
        prevYesRef.current = next
      })
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'trades',
        filter: `market_id=eq.${id}`,
      }, () => {
        fetchTrades()
      })
      .subscribe()

    return () => {
      if (channelRef.current) supabase.removeChannel(channelRef.current)
    }
  }, [id, user])

  const fetchMarket = async () => {
    const { data } = await supabase.from('markets').select('*').eq('id', id).single()
    if (data) {
      setMarket(data)
      prevYesRef.current = data.yes_price
      setPriceHistory([{ time: new Date().toLocaleTimeString(), yes: data.yes_price, no: data.no_price }])
    }
    setFetching(false)
  }

  const fetchTrades = async () => {
    const { data } = await supabase
      .from('trades')
      .select('id, side, amount, created_at, users(username)')
      .eq('market_id', id)
      .order('created_at', { ascending: false })
      .limit(25)
    if (data) setTrades(data)
  }

  if (loading || !user || fetching || !market) {
    return (
      <div style={{ minHeight: '100vh', background: '#0D0F14', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ color: '#6B7280', fontFamily: 'monospace', fontSize: 13 }}>Loading market...</div>
      </div>
    )
  }

  const name = market.question.replace(' will cry on farewell speech?', '')
  const yesPercent = (market.yes_price / 10).toFixed(1)
  const noPercent = (market.no_price / 10).toFixed(1)

  return (
    <>
      <Head><title>{name} — PredMarket</title></Head>

      <style>{`
        @keyframes livePulse { 0%,100% { opacity:1;transform:scale(1) } 50% { opacity:0.4;transform:scale(1.6) } }
        .live-dot { animation: livePulse 2s ease-in-out infinite; }
        .price-card { transition: background 0.6s ease; }
        .trade-feed-item { border-bottom: 1px solid #1E2330; }
        .trade-feed-item:last-child { border-bottom: none; }
      `}</style>

      <div style={{ minHeight: '100vh', background: '#0D0F14', fontFamily: "'Syne', sans-serif" }}>
        <Navbar />

        <div style={{ maxWidth: 1100, margin: '0 auto', padding: '28px 20px' }}>

          {/* Breadcrumb */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, fontFamily: 'monospace', color: '#6B7280', marginBottom: 24 }}>
            <Link href="/markets" style={{ color: '#6B7280', textDecoration: 'none', ':hover': { color: 'white' } }}>Markets</Link>
            <span>/</span>
            <span style={{ color: 'white' }}>{name}</span>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 20, alignItems: 'start' }}>

            {/* ── Left column ── */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

              {/* Market header */}
              <div
                ref={priceCardRef}
                className="price-card"
                style={{ background: '#141720', border: '1px solid #1E2330', borderRadius: 20, padding: 28 }}
              >
                {/* Title row */}
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: 16, marginBottom: 24 }}>
                  <div style={{
                    width: 52, height: 52, borderRadius: '50%', flexShrink: 0,
                    background: 'rgba(22,82,240,0.12)', border: '1px solid rgba(22,82,240,0.2)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: 20, fontWeight: 900, color: '#6699FF',
                  }}>
                    {name[0]}
                  </div>
                  <div style={{ flex: 1 }}>
                    <h1 style={{ color: 'white', fontSize: 22, fontWeight: 900, margin: 0, lineHeight: 1.2 }}>
                      {market.question}
                    </h1>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 8 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                        <div className="live-dot" style={{ width: 7, height: 7, borderRadius: '50%', background: '#00C278' }} />
                        <span style={{ color: '#00C278', fontSize: 11, fontFamily: 'monospace' }}>LIVE</span>
                      </div>
                      <span style={{ color: '#4B5563' }}>·</span>
                      <span style={{ color: '#6B7280', fontSize: 12, fontFamily: 'monospace' }}>
                        Vol: {formatRupees(market.volume || 0)}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Big YES / NO price boxes */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 20 }}>
                  <div style={{
                    background: 'rgba(0,194,120,0.06)', border: '1px solid rgba(0,194,120,0.2)',
                    borderRadius: 14, padding: '20px 16px', textAlign: 'center',
                  }}>
                    <div style={{ color: '#00C278', fontSize: 11, fontFamily: 'monospace', letterSpacing: '0.1em', marginBottom: 4 }}>YES</div>
                    <div style={{ color: '#00C278', fontSize: 40, fontWeight: 900, fontFamily: 'monospace', lineHeight: 1 }}>
                      {yesPercent}%
                    </div>
                    <div style={{ color: '#4B5563', fontSize: 12, fontFamily: 'monospace', marginTop: 4 }}>
                      ₹{market.yes_price} / share
                    </div>
                  </div>
                  <div style={{
                    background: 'rgba(255,77,77,0.06)', border: '1px solid rgba(255,77,77,0.2)',
                    borderRadius: 14, padding: '20px 16px', textAlign: 'center',
                  }}>
                    <div style={{ color: '#FF4D4D', fontSize: 11, fontFamily: 'monospace', letterSpacing: '0.1em', marginBottom: 4 }}>NO</div>
                    <div style={{ color: '#FF4D4D', fontSize: 40, fontWeight: 900, fontFamily: 'monospace', lineHeight: 1 }}>
                      {noPercent}%
                    </div>
                    <div style={{ color: '#4B5563', fontSize: 12, fontFamily: 'monospace', marginTop: 4 }}>
                      ₹{market.no_price} / share
                    </div>
                  </div>
                </div>

                {/* Progress bar */}
                <div style={{ display: 'flex', height: 8, borderRadius: 99, overflow: 'hidden', gap: 2 }}>
                  <div style={{
                    background: '#00C278', transition: 'width 0.8s ease',
                    width: `${yesPercent}%`, borderRadius: 99,
                  }} />
                  <div style={{ background: '#FF4D4D', flex: 1, borderRadius: 99 }} />
                </div>

                {/* Market details */}
                <div style={{ display: 'flex', gap: 20, marginTop: 16, flexWrap: 'wrap' }}>
                  {[
                    ['Type', 'Binary'],
                    ['Range', '₹0 – ₹1000'],
                    ['Starting YES', '70%'],
                    ['Resolves', 'Farewell Day'],
                  ].map(([k, v]) => (
                    <div key={k} style={{ fontSize: 12 }}>
                      <span style={{ color: '#6B7280' }}>{k}: </span>
                      <span style={{ color: '#9CA3AF', fontFamily: 'monospace' }}>{v}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Price history */}
              {priceHistory.length > 1 && (
                <div style={{ background: '#141720', border: '1px solid #1E2330', borderRadius: 18, padding: 24 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
                    <h3 style={{ color: 'white', fontSize: 14, fontWeight: 700, margin: 0 }}>Price History</h3>
                    <span style={{ background: '#0D0F14', border: '1px solid #1E2330', borderRadius: 6, padding: '2px 8px', fontSize: 10, fontFamily: 'monospace', color: '#6B7280' }}>
                      This session
                    </span>
                  </div>
                  <div style={{ maxHeight: 200, overflowY: 'auto' }}>
                    {[...priceHistory].reverse().map((p, i) => (
                      <div key={i} style={{
                        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                        padding: '8px 0', borderBottom: '1px solid #1E2330', fontSize: 12, fontFamily: 'monospace',
                      }}>
                        <span style={{ color: '#6B7280' }}>{p.time}</span>
                        <div style={{ display: 'flex', gap: 20 }}>
                          <span style={{ color: '#00C278' }}>YES {(p.yes / 10).toFixed(1)}%</span>
                          <span style={{ color: '#FF4D4D' }}>NO {(p.no / 10).toFixed(1)}%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* ── Right column ── */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

              {/* Trade panel */}
              <TradePanel market={market} onTrade={fetchTrades} />

              {/* Recent trades feed */}
              <div style={{ background: '#141720', border: '1px solid #1E2330', borderRadius: 18, padding: 24 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
                  <h3 style={{ color: 'white', fontSize: 14, fontWeight: 700, margin: 0 }}>Live Activity</h3>
                  <div className="live-dot" style={{ width: 6, height: 6, borderRadius: '50%', background: '#00C278' }} />
                </div>

                {trades.length === 0 ? (
                  <div style={{ textAlign: 'center', padding: '28px 0', color: '#6B7280', fontSize: 13 }}>
                    No trades yet. Be the first!
                  </div>
                ) : (
                  <div>
                    {trades.map((trade) => {
                      const isYes = trade.side === 'YES'
                      return (
                        <div
                          key={trade.id}
                          className="trade-feed-item"
                          style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 0' }}
                        >
                          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                            <div style={{
                              width: 28, height: 28, borderRadius: '50%', background: '#1E2330',
                              display: 'flex', alignItems: 'center', justifyContent: 'center',
                              fontSize: 11, fontWeight: 700, color: '#9CA3AF', flexShrink: 0,
                            }}>
                              {(trade.users?.username?.[0] || '?').toUpperCase()}
                            </div>
                            <div>
                              <div style={{ color: 'white', fontSize: 12, fontWeight: 600 }}>
                                {trade.users?.username || 'Anonymous'}
                              </div>
                              <div style={{ color: '#6B7280', fontSize: 10, fontFamily: 'monospace', marginTop: 1 }}>
                                {new Date(trade.created_at).toLocaleTimeString()}
                              </div>
                            </div>
                          </div>
                          <div style={{ textAlign: 'right' }}>
                            <div style={{
                              fontSize: 12, fontWeight: 700, fontFamily: 'monospace',
                              color: isYes ? '#00C278' : '#FF4D4D',
                            }}>
                              {trade.side}
                            </div>
                            <div style={{ color: '#6B7280', fontSize: 11, fontFamily: 'monospace', marginTop: 1 }}>
                              {formatRupees(trade.amount)}
                            </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                )}
              </div>

            </div>
          </div>
        </div>
      </div>
    </>
  )
}
