import { useState, useEffect } from 'react'
import { useRouter } from 'next/router'
import Head from 'next/head'
import { useAuth } from '../lib/auth'

const TICKER_ITEMS = [
  'Abhishek Mandot 70.0% YES', 'Anmol 30.0% NO', 'Arihant 70.0% YES',
  'Saina 55.0% YES', 'Dev 40.0% NO', 'Dhruv Chincholi 65.0% YES',
  'Hemang 62.0% YES', 'Jatin 38.0% NO', 'Bilal 55.0% YES',
  'Parth 70.0% YES', 'Raj 45.0% NO', 'Tanvi 80.0% YES',
  'Zuha 35.0% NO', 'Mayur 60.0% YES', 'Jayshree 75.0% YES',
]

export default function LoginPage() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const { login, user } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (user) router.replace('/markets')
  }, [user])

  const handleLogin = async (e) => {
    e.preventDefault()
    setError('')
    if (!username.trim()) {
      setError('Please enter your name')
      return
    }
    if (!password) {
      setError('Please enter the password')
      return
    }
    setLoading(true)
    try {
      await login(username.trim(), password)
      router.push('/markets')
    } catch (err) {
      setError(err.message || 'Login failed. Check your name and password.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      <Head>
        <title>Login — PredMarket</title>
      </Head>

      <div style={{
        minHeight: '100vh',
        background: 'radial-gradient(ellipse at 20% 50%, rgba(22,82,240,0.15) 0%, transparent 60%), radial-gradient(ellipse at 80% 20%, rgba(0,194,120,0.10) 0%, transparent 60%), #0D0F14',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '16px',
        position: 'relative',
        overflow: 'hidden',
        fontFamily: "'Syne', sans-serif",
      }}>

        {/* Grid background */}
        <div style={{
          position: 'absolute', inset: 0, opacity: 0.03,
          backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)',
          backgroundSize: '60px 60px', pointerEvents: 'none',
        }} />

        {/* Glow orbs */}
        <div style={{ position: 'absolute', top: '25%', left: '20%', width: 320, height: 320, borderRadius: '50%', background: 'rgba(22,82,240,0.08)', filter: 'blur(80px)', pointerEvents: 'none' }} />
        <div style={{ position: 'absolute', bottom: '30%', right: '20%', width: 240, height: 240, borderRadius: '50%', background: 'rgba(0,194,120,0.07)', filter: 'blur(80px)', pointerEvents: 'none' }} />

        {/* Ticker tape */}
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0,
          height: 32, background: '#141720', borderBottom: '1px solid #1E2330',
          overflow: 'hidden', display: 'flex', alignItems: 'center',
          zIndex: 10,
        }}>
          <div style={{
            display: 'flex', gap: 48, whiteSpace: 'nowrap',
            animation: 'ticker 35s linear infinite',
            fontSize: 11, fontFamily: 'monospace', color: '#6B7280',
          }}>
            {[...TICKER_ITEMS, ...TICKER_ITEMS].map((item, i) => (
              <span key={i} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <span style={{ color: item.includes('YES') ? '#00C278' : '#FF4D4D' }}>●</span>
                {item}
              </span>
            ))}
          </div>
        </div>

        <style>{`
          @keyframes ticker { from { transform: translateX(0) } to { transform: translateX(-50%) } }
          @keyframes fadeSlideUp { from { opacity: 0; transform: translateY(20px) } to { opacity: 1; transform: translateY(0) } }
          @keyframes livePulse { 0%,100% { opacity:1; transform:scale(1) } 50% { opacity:0.4; transform:scale(1.6) } }
          .login-card { animation: fadeSlideUp 0.5s ease-out both; }
          .live-dot { animation: livePulse 2s ease-in-out infinite; }
          .login-input {
            background: #0D0F14; border: 1px solid #1E2330; border-radius: 10px;
            padding: 12px 16px; color: white; font-size: 15px; width: 100%;
            box-sizing: border-box; font-family: 'Syne', sans-serif; outline: none;
            transition: border-color 0.2s;
          }
          .login-input:focus { border-color: #1652F0; box-shadow: 0 0 0 3px rgba(22,82,240,0.15); }
          .login-input::placeholder { color: #4B5563; }
          .login-btn {
            width: 100%; padding: 14px; border-radius: 12px; border: none; cursor: pointer;
            background: #1652F0; color: white; font-size: 15px; font-weight: 700;
            font-family: 'Syne', sans-serif; transition: all 0.2s; letter-spacing: 0.01em;
          }
          .login-btn:hover:not(:disabled) { background: #2563eb; transform: translateY(-1px); box-shadow: 0 8px 24px rgba(22,82,240,0.35); }
          .login-btn:active:not(:disabled) { transform: scale(0.98); }
          .login-btn:disabled { opacity: 0.5; cursor: not-allowed; }
        `}</style>

        {/* Main card */}
        <div className="login-card" style={{
          width: '100%', maxWidth: 400, marginTop: 32, position: 'relative', zIndex: 1,
        }}>
          {/* Logo */}
          <div style={{ textAlign: 'center', marginBottom: 28 }}>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
              <div style={{
                width: 40, height: 40, borderRadius: 10, background: '#1652F0',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <span style={{ color: 'white', fontWeight: 900, fontSize: 14 }}>PM</span>
              </div>
              <span style={{ fontSize: 24, fontWeight: 900, color: 'white', letterSpacing: '-0.02em' }}>
                Pred<span style={{ color: '#1652F0' }}>Market</span>
              </span>
            </div>
            <p style={{ color: '#6B7280', fontSize: 13, margin: 0 }}>
              MFT Farewell Prediction Market
            </p>
          </div>

          {/* Card */}
          <div style={{
            background: '#141720', border: '1px solid #1E2330', borderRadius: 20,
            padding: 28, boxShadow: '0 24px 64px rgba(0,0,0,0.5)',
          }}>
            <h1 style={{ color: 'white', fontSize: 22, fontWeight: 800, margin: '0 0 4px' }}>
              Welcome back
            </h1>
            <p style={{ color: '#6B7280', fontSize: 13, margin: '0 0 24px' }}>
              Trade outcomes. Win bragging rights.
            </p>

            <form onSubmit={handleLogin}>
              <div style={{ marginBottom: 16 }}>
                <label style={{ display: 'block', color: '#9CA3AF', fontSize: 11, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 6 }}>
                  Your Name
                </label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="e.g. Abhishek Mandot"
                  className="login-input"
                  autoFocus
                  autoComplete="off"
                />
              </div>

              <div style={{ marginBottom: 20 }}>
                <label style={{ display: 'block', color: '#9CA3AF', fontSize: 11, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 6 }}>
                  Password
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••"
                  className="login-input"
                />
              </div>

              {error && (
                <div style={{
                  background: 'rgba(255,77,77,0.1)', border: '1px solid rgba(255,77,77,0.3)',
                  borderRadius: 10, padding: '10px 14px', marginBottom: 16,
                  color: '#FF6B6B', fontSize: 13,
                }}>
                  {error}
                </div>
              )}

              <button type="submit" disabled={loading} className="login-btn">
                {loading ? 'Signing in...' : 'Enter the Market →'}
              </button>
            </form>

            {/* Stats row */}
            <div style={{
              marginTop: 24, paddingTop: 20, borderTop: '1px solid #1E2330',
              display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12, textAlign: 'center',
            }}>
              {[
                { label: 'Markets', value: '28' },
                { label: 'Starting ₹', value: '10L' },
                { label: 'Status', value: '🟢' },
              ].map(({ label, value }) => (
                <div key={label}>
                  <div style={{ color: 'white', fontWeight: 800, fontSize: 18, fontFamily: 'monospace' }}>{value}</div>
                  <div style={{ color: '#6B7280', fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.08em', marginTop: 2 }}>{label}</div>
                </div>
              ))}
            </div>
          </div>

          <p style={{ textAlign: 'center', color: '#4B5563', fontSize: 12, marginTop: 16 }}>
            Paper trading only · No real money involved
          </p>
        </div>
      </div>
    </>
  )
}
